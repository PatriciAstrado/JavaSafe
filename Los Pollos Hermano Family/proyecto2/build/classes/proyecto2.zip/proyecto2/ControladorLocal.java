/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2;

import java.awt.List;
import java.util.ArrayList;

public class ControladorLocal {

  private Administrador manager;
  private Menu menu = new Menu();
  private ArrayList<Empleado> empleados;
  private Cajero refereciaCajero;
  private Menu menuPedido = new Menu();
  private String rutMeseroActual;
  private boolean accedido = false;
  private boolean hayCajero = false;

  // si no existe un manager de antes, se llama esto
  public ControladorLocal(String rut, String nombre, String apellido, int telefono, String contraseña) {
    this.manager = new Administrador(rut, nombre, apellido, telefono, contraseña);
    this.accedido = true;
    this.empleados = new ArrayList<>();
    System.out.println("No hay empleados contratados");
  }
  public ControladorLocal(String contraseña) { // si ya hay un manager guradado se carga apartir de la constraseña
    if (this.manager.validarClave(contraseña)) {
      System.out.println("ingresado");
      this.accedido = true;
      revisaCajero();
    }
  }
  private void revisaCajero() {
    hayCajero = false;
    for (Empleado empleado : this.empleados) {
      if (empleado instanceof Cajero) {
    
        hayCajero = true;
        refereciaCajero = (Cajero)empleado;
        return;
      }
    }
    System.out.println("No hay un cajero contratado.");
  }
  /* funcion que retorna las ganancias totales de todas la boletas en el cajero
 public int checkChecker(){
     return this.refereciaCajero.gastosTotales();
 }*/
  public void agregarEmpleado(int tipo, String rut, String nombre, String apellido, int telefono) {
    if (this.accedido) { // solo se puede usar si se accedio con la contraseña
      switch (tipo) {
      case 1: // mesero
        this.manager.agregarEmpleado(empleados, new Mesero(rut, nombre, apellido, telefono));
        break;
      case 2: // cajero
        this.manager.agregarEmpleado(empleados, new Cajero(rut, nombre, apellido, telefono));
        hayCajero = true;
        break;
      }
    }
  }
  public void modificarEmpleado(String rut, boolean onOff) {
    Empleado empleado = this.manager.buscarEmpleadoPorRut(empleados, rut);
    if (empleado != null) {
      this.manager.modificarEmpleadoEstado(empleado, onOff);
      System.out.println("Estado del empleado modificado correctamente.");
    } else {
      System.out.println("Error: No se encontró el empleado con RUT: " + rut);
    }
  }
  public void modificarEmpleado(String rut, boolean onOff, int telefono) {
    Empleado empleado = this.manager.buscarEmpleadoPorRut(empleados, rut);
    if (empleado != null) {
      this.manager.modificarEmpleadoEstado(empleado, onOff);
      empleado.setTelefono(telefono);
      System.out.println("Estado del empleado modificado correctamente.");
    } else {
      System.out.println("Error: No se encontró el empleado con RUT: " + rut);
    }
  }

  public void agregarPlatillo(String nombre, String descripcion, int valor) {
    if (this.accedido) {
      this.manager.modificarMenu(menu, new Platillo(nombre, descripcion, valor), true);
    }
  }

  public void quitarPlatillo(String nombre) { // busca el platillo dado el nombre
    if (this.accedido) {
      System.out.println("removido2");
      this.manager.removerDeMenu(menu, nombre);
    }
  }

  public void agregarQuitarPedido(int opcion, String nombre) {
    if (!hayCajero)
      return;

    Platillo plato = menu.buscarPlatillo(nombre);
    if (plato == null) {
      System.out.println("Error: No existe el platillo con nombre:" + nombre);
      return;
    }

    switch (opcion) {
    case 1:
      this.menuPedido.agregarPlatillo(plato);
      System.out.println("Platillo agregado al pedido.");
      break;
    case 2:
      this.menuPedido.eliminarPlatillo(plato);
      System.out.println("Platillo eliminado del pedido.");
      break;
    default:
      System.out.println("Opción inválida.");
    }
  }
  public void TerminarPedido(String rutMesero) {
    revisaCajero();
    if (!hayCajero)
      return;

    Empleado empleado = this.manager.buscarEmpleadoPorRut(this.empleados, rutMesero);
    if (empleado instanceof Mesero mesero) {
      Pedido pedido = mesero.procesarPedidoMenu(this.menuPedido); // Procesa el pedido
      this.refereciaCajero.procesarPago(pedido);                  // Procesa el pago
      this.menuPedido = new Menu();                               // Limpia el menú de pedidos
      System.out.println("Pedido procesado y pagado correctamente.");
    } else {
      System.out.println("Error: El empleado con RUT: " + rutMesero + " no es un mesero.");
    }
  }

  public void TerminarPedido() { // sin llamada para forma semi automatica
    revisaCajero();
    if (!hayCajero)
      return;
    Empleado empleado = this.manager.buscarEmpleadoPorRut(this.empleados, rutMeseroActual);
    if (empleado instanceof Mesero mesero) {
      Pedido pedido = mesero.procesarPedidoMenu(this.menuPedido); // Procesa el pedido
      this.refereciaCajero.procesarPago(pedido);                  // Procesa el pago
      this.menuPedido = new Menu();                               // Limpia el menú de pedidos
      System.out.println("Pedido procesado y pagado correctamente.");
    } else {
      //System.out.println("Error: El empleado con RUT: " + rutMeseroActual + " no es un mesero.");
    }
  }

  public int conseguirGananciasTotales() {
    if (!hayCajero)
      return -1;

    return this.refereciaCajero.gastosTotalesOriginales();
  }
  /*
  private boolean validarCajero() {
      if (!hayCajero) {
          System.out.println("Error: No hay un cajero registrado.");
          return false;
      }
      return true;
  }
      */

  public String nombrePlato(int posicionMenu) {
    String nombre = (menu.buscarPlatillo(posicionMenu)).getNombre();
    return nombre;
  }
  public Platillo getPlato(int posicionMenu) {
    return menu.buscarPlatillo(posicionMenu);
  }
  public Platillo objPlato(int posicionMenu) {
    return menu.buscarPlatillo(posicionMenu);
  }
  public int cantidadPlatos() {
    return menu.getListaPlatillos().size();
  }
  public Mesero[] listaMeseros() {
    ArrayList<Mesero> lista = new ArrayList<>();
    for (Empleado empleado : this.empleados) {
      if (empleado instanceof Mesero) {
        lista.add((Mesero)empleado); // Hacemos el casting explícito a Mesero
      }
    }
    return lista.toArray(new Mesero[0]); // Convertimos la lista a un array de Mesero
  }

  public Mesero[] listaMeserosDisponibles() {
    ArrayList<Mesero> lista = new ArrayList<>();
    for (Empleado empleado : this.empleados) {
      if (empleado instanceof Mesero && empleado.isActivo()) {
        lista.add((Mesero)empleado); // Hacemos el casting explícito a Mesero
      }
    }
    if (lista.isEmpty()) {

      return null;
    }
    return lista.toArray(new Mesero[0]); // Convertimos la lista a un array de Mesero
  }
  public void actMeseroActual(String rut) {
    if (rut != null) {
      this.rutMeseroActual = rut;
    } else {
      this.rutMeseroActual = "rut no ingresado";
    }
  }

  public void onOffLogin() {
    if (this.accedido == true) { // log off si ya esta conectado
      accedido = false;
    }
  }
  public void onOffLogin(String pswr) {
    if (this.accedido == false && this.manager.validarClave(pswr)) { // log on si no esta conectado y paso la contraseña correcta
      this.accedido = true;
      System.out.println("CONTRASEÑA EXITOSA; LOG ON");
    }
  }
  public boolean logOnOff() {
    return this.accedido;
  }
  public boolean existePlatoEnMenu(String nombre) {
    if (this.menu.buscarPlatillo(nombre) instanceof Platillo) {
      return true;
    }
    return false;
  }
  public void actualizarPlatoMenu(String nombrePlatillo, String nuevoNombre, int nuevoValor, String nuevaDescripcion) {
    this.menu.actualizarPlatillo(this.menu.buscarPlatillo(nombrePlatillo), nuevoNombre, nuevaDescripcion, nuevoValor);
  }
  private Empleado buscarEmpleadoPorRut(String rut) {
    return this.manager.buscarEmpleadoPorRut(empleados, rut);
  }
  public boolean existeEmpleado(String rut) {
    if (buscarEmpleadoPorRut(rut) instanceof Empleado) {
      return true;
    }
    return false;
  }

  public String[][] dataPedido() {
    return this.menuPedido.getArrayData();
  }
  public int precioTotal() {
    return this.menuPedido.gastoTotal();
  } // funcion devolver el total de gastos de el pedido

  public boolean estadoEmpleado(String rut) {
    return buscarEmpleadoPorRut(rut).isActivo();
  }
  
}
