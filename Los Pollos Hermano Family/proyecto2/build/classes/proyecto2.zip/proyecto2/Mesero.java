/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2;

import java.util.Scanner;


public class Mesero extends Empleado {

    public Mesero(String rut, String nombre, String apellido, int telefono) {
        super(rut, nombre, apellido, telefono);
        
    }

    public Pedido tomarPedido(Menu menu) {
        Scanner scanner = new Scanner(System.in);
        Pedido pedido = new Pedido();
        menu.imprimir();
        boolean continuar = true;
        while (continuar) {
            //System.out.print("Selecciona el nombre del platillo o escribe 'fin' para terminar el pedido: ");
            String platilloNombre = scanner.nextLine();
            if (platilloNombre.equalsIgnoreCase("fin")) {
                continuar = false;
            } else {
                Platillo platillo = menu.buscarPlatillo(platilloNombre);
                if (platillo != null) {
                    pedido.agregarPlatillo(platillo);
                } else {
                  //  System.out.println("Platillo no encontrado. Intenta de nuevo.");
                }
            }
        }
        return pedido;
    }
     public Pedido procesarPedidoMenu(Menu menu){
        Pedido pedido= new Pedido();
        for (Platillo platillo : menu.getListaPlatillos()) {
            pedido.agregarPlatillo(platillo);
        }
         return pedido;
     }
     public Mesero self(){
         return this;
     }
     public String getNombreCompleto(){
         return getNombre() + " " + getApellido();
     }

}
