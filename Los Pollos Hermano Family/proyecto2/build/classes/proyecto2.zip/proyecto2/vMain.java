package proyecto2;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.*;
import net.miginfocom.swing.MigLayout;

public class vMain {
    private ControladorLocal local;
    private JPanel mainPanel;
    private JScrollPane scrollPane;
    private JLabel lblPrecioFinal;
    private vCombo comboMeseros;
    private JPanel scrollContent;
    
    // Panel donde se mostrarán los platillos añadidos (en la sección inferior derecha)
    private JPanel panelItemsSeleccionados;
    private JScrollPane scrollItems;
    public vMain(ControladorLocal local) {
        this.local = local;
        cargar();
    }

    public void cargar() {
        // Crear el marco principal (framePrincipal)
        JFrame marco = new JFrame("Los Pollos Hermanos APP");
        marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marco.setSize(1000, 700);
        marco.setLocationRelativeTo(null); // Centrar en la pantalla

        // Layout principal
        mainPanel = new JPanel(new MigLayout("insets 3, gap 0", "[300px!][grow,fill]", "[grow,fill]"));
        // mainPanel.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
        marco.add(mainPanel);

        // Panel Contenedor 1 (Izquierda)
        JPanel panelContenedor1 = new JPanel(new MigLayout("insets 0, gap 0", "[grow,fill]", "[grow,fill]"));
        // panelContenedor1.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));
        mainPanel.add(panelContenedor1, "cell 0 0,grow");

        // Panel de contenido con scroll (Platos disponibles)
        scrollContent = new JPanel(new MigLayout("wrap 1, insets 0", "[grow,fill]", "[]10[]"));
        scrollPane = new JScrollPane(scrollContent);
        // scrollPane.setBorder(BorderFactory.createLineBorder(Color.CYAN, 2));
        panelContenedor1.add(scrollPane, "grow,push");

        // Agregar ítems dinámicos (lista de platillos disponibles)
        for (int i = 0; i < local.cantidadPlatos(); i++) {
            agregar(scrollContent, i);
        }

        // Panel Contenedor 2 (Derecha)
        // Lo dividimos verticalmente en dos partes proporcionales (magenta arriba, verde abajo)
        // y el label de precio final al fondo (south).
        JPanel panelContenedor2 = new JPanel(new MigLayout("insets 0, gap 0, fill", "[grow,fill]", "[grow,fill][grow,fill][]"));
        // panelContenedor2.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 2));
        mainPanel.add(panelContenedor2, "cell 1 0,grow");

        // Sección superior (panelJpanel1) - Magenta
        JPanel panelJpanel1 = new JPanel(new MigLayout("insets 0, gap 5", "[][][][]", "[]"));
        // panelJpanel1.setBorder(BorderFactory.createLineBorder(Color.MAGENTA, 2));
        // Hacemos que crezca verticalmente (growy) para repartirse el espacio con el panel verde
        panelContenedor2.add(panelJpanel1, "growx, growy, wrap");

        // Botones y combo en panelJpanel1
        JButton log = (new vBotonLogin(local, this)).jbut();
        // log.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
        panelJpanel1.add(log, "growx");

        JButton botonGenerarBoleta = (new vBotonGenBoleta(local, this)).jbut();
        // botonGenerarBoleta.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
        panelJpanel1.add(botonGenerarBoleta, "growx");

        comboMeseros = new vCombo(local);
        JComboBox combo = comboMeseros.getCombo();
        // combo.setBorder(BorderFactory.createLineBorder(Color.CYAN, 2));
        panelJpanel1.add(combo, "growx");

        JButton botonVerBoletas = new JButton("Ver Boletas");
        // botonVerBoletas.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
        botonVerBoletas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/los_pollos", "root", "");
                    new vDetalleBoleta(connection);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panelJpanel1.add(botonVerBoletas, "growx, wrap");

        // Sección inferior del contenedor2: panel de listado verde
        // Contiene la fila de encabezados ("Platillo" y "Precio") y la lista de platillos añadidos
        JPanel panelListado = new JPanel(new MigLayout("insets 0, gap 0, fill", "[grow,fill][grow,fill]", "[]0[grow,fill]"));
        // panelListado.setBorder(BorderFactory.createLineBorder(Color.GREEN, 2));
        panelContenedor2.add(panelListado, "grow, wrap"); // grow para compartir verticalmente con el panel magenta

        // Fila de encabezados (40px de alto)
        JPanel panelEncabezados = new JPanel(new MigLayout("insets 0, gap 0", "[grow,fill][grow,fill]", "[40px!]"));
        // panelEncabezados.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panelListado.add(panelEncabezados, "span 2, growx, wrap");

        JLabel lblPlatillo = new JLabel("Platillo");
        lblPlatillo.setHorizontalAlignment(SwingConstants.CENTER);
        panelEncabezados.add(lblPlatillo, "growx");

        JLabel lblPrecio = new JLabel("Precio");
        lblPrecio.setHorizontalAlignment(SwingConstants.CENTER);
        panelEncabezados.add(lblPrecio, "growx");

        // Lista de platillos seleccionados
        panelItemsSeleccionados = new JPanel(new MigLayout("insets 0, wrap 2", "[grow,fill][grow,fill]", ""));
        scrollItems = new JScrollPane(panelItemsSeleccionados);
        // scrollItems.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
        panelListado.add(scrollItems, "span 2, grow");

        // Label de precio final al fondo (south)
        lblPrecioFinal = new JLabel("Precio Final: $0.00");
        lblPrecioFinal.setFont(new Font("Arial", Font.BOLD, 16));
        lblPrecioFinal.setHorizontalAlignment(SwingConstants.CENTER);
        // lblPrecioFinal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panelContenedor2.add(lblPrecioFinal, "dock south, growx");

        marco.setVisible(true);
    }

    private void agregar(JPanel scrollContent, int posicionLista) {
        JPanel panelItem = new JPanel(new MigLayout("wrap 4, insets 10", "[grow][grow][grow][grow]", "[]10[]"));
        panelItem.setBackground(Color.WHITE);
        // panelItem.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JLabel label = (new vNombrePlato(posicionLista, local)).getLabel();
        panelItem.add(label, "span 1, align center");

        JButton botonMas = (new vBotonMas(posicionLista, local, this)).jbut();
        // botonMas.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
        panelItem.add(botonMas, "growx, gap 5");

        JButton botonMenos = (new vBotonMenos(posicionLista, local, this)).jbut();
        // botonMenos.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
        panelItem.add(botonMenos, "growx, gap 5, wrap");

        JTextField textField = (new vDescripcion(posicionLista, local)).getTextField();
        // textField.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
        panelItem.add(textField, "span 4, growx, wrap");

        scrollContent.add(panelItem, "growx, wrap");
        
    }

    public void actualizarLista() {
        scrollContent.removeAll();
        // Aquí se refrescaría la lista si fuera necesario
        for (int i = 0; i < local.cantidadPlatos(); i++) {
        agregar(scrollContent,i); 
        }
        scrollContent.revalidate(); 
        scrollContent.repaint(); 
    }

    public void actualizarCombo() {
        comboMeseros.act();
    }

    public void actualizarTabla() {
        String[] datos = { "Platillo", "Precio" }; 
    String[][] data = this.local.dataPedido();
    JTable tabla = new JTable(data, datos);
       
    // Si ScrollTabla ya existe, actualiza su contenido
    if (scrollItems != null) {
        
        scrollItems.setViewportView(tabla); // Cambia el contenido sin crear un nuevo JScrollPane
    } else {
        
        scrollItems = new JScrollPane(tabla); // Crea ScrollTabla 
        
    }
    scrollItems.revalidate();
    scrollItems.repaint();
    lblPrecioFinal.setText(String.format("Precio Final: $%,.2f", (double) this.local.precioTotal()));
    lblPrecioFinal.getParent().revalidate();
    lblPrecioFinal.getParent().repaint();

    }
    

    public void actualizarPrecioFinal(double precio) {
        lblPrecioFinal.setText(String.format("Precio Final: $%.2f", precio));
    }

    // Método para agregar platillos seleccionados al panelItemsSeleccionados
    public void agregarPlatilloSeleccionado(Platillo plato) {
        JLabel lblNombre = new JLabel(plato.getNombre());
        // lblNombre.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        lblNombre.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel lblValor = new JLabel(String.format("$%.2f", plato.getValor()));
        // lblValor.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        lblValor.setHorizontalAlignment(SwingConstants.CENTER);

        panelItemsSeleccionados.add(lblNombre, "growx");
        panelItemsSeleccionados.add(lblValor, "growx, wrap");
        panelItemsSeleccionados.revalidate();
        panelItemsSeleccionados.repaint();
    }
    
   
}
